<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\RekamanStok;
use App\Models\Produk;
use Illuminate\Support\Facades\DB;

echo "=== SCRIPT PERBAIKAN REKAMAN STOK ===\n";
echo "Mulai perbaikan...\n\n";

// Disable query log to save memory
DB::connection()->disableQueryLog();

$products = Produk::all();
$count = 0;
$total = $products->count();

foreach ($products as $produk) {
    $count++;
    echo "Processing Product {$count}/{$total}: {$produk->nama_produk} (ID: {$produk->id_produk})... ";
    
    $stokRecords = RekamanStok::where('id_produk', $produk->id_produk)
        ->orderBy('waktu', 'asc')
        ->orderBy('created_at', 'asc')
        ->orderBy('id_rekaman_stok', 'asc')
        ->get();
        
    if ($stokRecords->isEmpty()) {
        echo "No records found.\n";
        continue;
    }
    
    $runningStock = 0;
    $isFirst = true;
    $changesCount = 0;
    
    DB::beginTransaction();
    try {
        foreach ($stokRecords as $record) {
            $needsUpdate = false;
            
            if ($isFirst) {
                // For the first record, we trust its stok_awal as the starting point
                $runningStock = $record->stok_awal;
                $isFirst = false;
            } else {
                // For subsequent records, stok_awal MUST match previous stok_sisa
                if ($record->stok_awal != $runningStock) {
                    $record->stok_awal = $runningStock;
                    $needsUpdate = true;
                }
            }
            
            // Calculate sisa
            $calculatedSisa = $runningStock + $record->stok_masuk - $record->stok_keluar;
            
            if ($record->stok_sisa != $calculatedSisa) {
                $record->stok_sisa = $calculatedSisa;
                $needsUpdate = true;
            }
            
            if ($needsUpdate) {
                // Use DB update to avoid model events overhead and potential issues
                DB::table('rekaman_stoks')
                    ->where('id_rekaman_stok', $record->id_rekaman_stok)
                    ->update([
                        'stok_awal' => $record->stok_awal,
                        'stok_sisa' => $record->stok_sisa
                    ]);
                $changesCount++;
            }
            
            $runningStock = $calculatedSisa;
        }
        
        // Update Product Master Stock
        if ($produk->stok != $runningStock) {
            echo "Updating Product Stock from {$produk->stok} to {$runningStock}. ";
            $produk->stok = $runningStock;
            $produk->save();
        }
        
        DB::commit();
        echo "Done. Updated {$changesCount} records.\n";
        
    } catch (\Exception $e) {
        DB::rollBack();
        echo "ERROR: " . $e->getMessage() . "\n";
    }
}

echo "\nPerbaikan Selesai.\n";
